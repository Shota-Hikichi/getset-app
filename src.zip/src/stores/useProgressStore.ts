// src/stores/useProgressStore.ts
import { create } from "zustand";

type ProgressState = {
  // ステップ1: インテンシティ変更完了
  intensityDone: boolean;
  // ステップ2: リチャージ挿入完了
  rechargeDone: boolean;
  // ステップ3: 具体的アクション選択完了
  detailDone: boolean;

  setIntensityDone: (done: boolean) => void;
  setRechargeDone: (done: boolean) => void;
  setDetailDone: (done: boolean) => void;
};

export const useProgressStore = create<ProgressState>((set) => ({
  intensityDone: false,
  rechargeDone: false,
  detailDone: false,

  setIntensityDone: (done) => set({ intensityDone: done }),
  setRechargeDone: (done) => set({ rechargeDone: done }),
  setDetailDone: (done) => set({ detailDone: done }),
}));
