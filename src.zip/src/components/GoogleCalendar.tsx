// src/components/GoogleCalendar.tsx
import React, { useEffect, useState } from "react";
import { nanoid } from "nanoid";
import googleApi from "../lib/googleApi";
import type { CalendarEvent } from "../types/calendar";
import CalendarEventCard from "./CalendarEventCard";
import RechargeDetailCard from "./RechargeDetailCard";
import type { RechargeAction } from "../types/recharge";
import {
  useRechargesStore,
  type RechargeSlot,
} from "../stores/useRechargesStore";

// サンプルの具体行動リスト
const SAMPLE_ACTIONS: RechargeAction[] = [
  { label: "ホットヨガ", duration: "30分", recovery: 4 },
  { label: "屋上庭園でストレッチ", duration: "60分", recovery: 5 },
  { label: "散歩", duration: "15分", recovery: 3 },
];

type CombinedItem = CalendarEvent & {
  isRecharge: boolean;
  slotId?: string;
};

// ISO 8601 or object から string を取り出す
function normalizeDate(
  val: string | { dateTime?: string; date?: string }
): string {
  return typeof val === "string" ? val : val.dateTime ?? val.date ?? "";
}

// HH:mm + XX分 で終了時刻を計算
function addMinutes(start: string, duration: string): string {
  const [h, m] = start.split(":").map((s) => parseInt(s, 10));
  const d = parseInt(duration.replace(/[^0-9]/g, ""), 10);
  const total = h * 60 + m + d;
  const newH = Math.floor(total / 60) % 24;
  const newM = total % 60;
  return `${newH.toString().padStart(2, "0")}:
${newM.toString().padStart(2, "0")}`.replace("\n", "");
}

const GoogleCalendar: React.FC = () => {
  // 1) Google 予定読み込み
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  // 2) 強度保持
  const [selectedIntensity, setSelectedIntensity] = useState<
    Record<string, number>
  >({});
  // 3) 展開 ID
  const [expandedId, setExpandedId] = useState<string | null>(null);
  // 4) アクション選択
  const [pickedAction, setPickedAction] = useState<
    Record<string, RechargeAction>
  >({});

  const rechargeSlots = useRechargesStore((s) => s.slots as RechargeSlot[]);
  const addRecharge = useRechargesStore((s) => s.addRecharge);
  const removeRecharge = useRechargesStore((s) => s.removeRecharge);

  useEffect(() => {
    (async () => {
      await googleApi.initGoogleApi();
      const fetched = await googleApi.listUpcomingEvents();
      setEvents(
        fetched.map((e) => ({
          id: e.id,
          summary: e.summary,
          start: normalizeDate(e.start),
          end: normalizeDate(e.end),
          intensity: 0,
        }))
      );
    })();
  }, []);

  // 結合リスト作成
  const [combined, setCombined] = useState<CombinedItem[]>([]);
  useEffect(() => {
    const items: CombinedItem[] = events.map((e) => ({
      ...e,
      isRecharge: false,
    }));

    rechargeSlots.forEach((r, idx) => {
      // slot.time は "HH:mm - HH:mm"
      const [rawStart, rawEnd] =
        typeof r.time === "string" ? r.time.split(" - ") : ["", ""];
      const start = rawStart;
      const end = pickedAction[r.id]
        ? addMinutes(start, pickedAction[r.id].duration)
        : rawEnd;

      // items に挿入（ここでは idx+1）
      const insertAt = Math.min(idx + 1, items.length);
      items.splice(insertAt, 0, {
        id: r.id,
        summary: r.category,
        start,
        end,
        intensity: selectedIntensity[r.id] ?? 0,
        isRecharge: true,
        slotId: r.id,
      });
    });
    setCombined(items);
  }, [events, rechargeSlots, pickedAction, selectedIntensity]);

  // 追加時は位置のみ固定、展開はタップで
  const handleAddRecharge = () => {
    if (!events.length) return;
    const idx = Math.floor(Math.random() * events.length);
    const ev = events[idx];
    const time = `${ev.start} - ${ev.start}`;
    addRecharge({ id: nanoid(), time, category: "リチャージ", actions: [] });
    // 展開は自分でタップしてください
  };

  const handleIntensityChange = (id: string, lvl: number) => {
    setSelectedIntensity((p) => ({ ...p, [id]: lvl }));
  };

  return (
    <div className="mt-4 p-2 space-y-4">
      <button
        onClick={handleAddRecharge}
        className="px-4 py-2 bg-blue-600 text-white rounded"
      >
        リチャージを予定に入れる
      </button>

      {combined.map((item) =>
        item.isRecharge ? (
          <React.Fragment key={item.id}>
            {expandedId === item.id ? (
              <RechargeDetailCard
                title={pickedAction[item.id]?.label ?? item.summary}
                time={
                  item.end === item.start
                    ? item.start
                    : `${item.start} - ${item.end}`
                }
                actions={SAMPLE_ACTIONS}
                onSelect={(action) => {
                  setPickedAction((p) => ({ ...p, [item.id]: action }));
                }}
                isRecharge
              />
            ) : (
              <div onClick={() => setExpandedId(item.id)}>
                <CalendarEventCard
                  id={item.id}
                  title={pickedAction[item.id]?.label ?? item.summary}
                  start={item.start}
                  end={item.end}
                  intensity={selectedIntensity[item.id] ?? 0}
                  onChange={(lvl) => handleIntensityChange(item.id, lvl)}
                  isRecharge
                  onDelete={() => removeRecharge(item.id)}
                />
              </div>
            )}
          </React.Fragment>
        ) : (
          <CalendarEventCard
            key={item.id}
            id={item.id}
            title={item.summary}
            start={item.start}
            end={item.end}
            intensity={selectedIntensity[item.id] ?? item.intensity}
            onChange={(lvl) => handleIntensityChange(item.id, lvl)}
          />
        )
      )}
    </div>
  );
};

export default GoogleCalendar;
